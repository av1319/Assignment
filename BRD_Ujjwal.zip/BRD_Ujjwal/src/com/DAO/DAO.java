package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.POJO.CustomerPOJO;
import com.connection.ConnectionInterface;
import com.connection.FactoryClass;

public class DAO implements DAOInterface {

Connection conn=null;
PreparedStatement ps = null;
Statement st = null;
int count=0;
ConnectionInterface c=FactoryClass.getConnectionMethod("oracle");

//Methods for inserting data in the database

public void insert(CustomerPOJO x){
	conn = c.myConnection();
//	try {
//		conn.setAutoCommit(false);
//	} catch (SQLException e1) {
//		e1.printStackTrace();
//	}
	if(conn!=null){
		try {
			ps = conn.prepareStatement("insert into UjjwalCustomer values(ucustid.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, x.getCustomerCode());
			ps.setString(2, x.getCustomerName());
			ps.setString(3, x.getAddress1());
			ps.setString(4, x.getAddress2());
			ps.setString(5,x.getCustomerPinCode());
			ps.setString(6, x.getEmail());
			ps.setString(7, x.getContact());
			ps.setString(8,x.getPrimary_person());
			ps.setString(9, x.getRecordStatus());
			ps.setString(10, x.getActive_flag());
			ps.setString(11, x.getCreateDate());
			ps.setString(12, x.getCreatedBy());
			ps.setString(13,x.getModifiedDate());
			ps.setString(14, x.getModifiedBy());
			ps.setString(15,x.getAuthorizedDate());
			ps.setString(16, x.getAuthorizedBy());
			
			count = ps.executeUpdate();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			try{
			ps.close();//Close the prepared connection
			conn.close();//Close the connection object
			}
			catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}		
	}
	else
		System.out.println("Not Connected..");
	
}

}