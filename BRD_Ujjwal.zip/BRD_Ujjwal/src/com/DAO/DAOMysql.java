package com.DAO;

import com.POJO.CustomerPOJO;

public class DAOMysql implements DAOInterface {
public void insert(CustomerPOJO cp){}
}
