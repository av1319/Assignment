package com.DAO;



public class DAOFactory {
	static DAOInterface dao;
public static DAOInterface getDAO(String str){
	if(str.equals("oracle")){
		return new DAO();
		
	}
	else if(str.equalsIgnoreCase("mysql")){
		return new DAOMysql();
	}
	return dao;
		
}
}
