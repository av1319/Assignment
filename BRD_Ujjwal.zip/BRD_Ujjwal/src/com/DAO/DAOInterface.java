package com.DAO;

import com.POJO.CustomerPOJO;

public interface DAOInterface {
	public void insert(CustomerPOJO cp);
}
