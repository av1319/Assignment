package com.fileread;

import com.DAO.DAO;
import com.DAO.DAOInterface;
import com.POJO.CustomerPOJO;

public class Split {
public void split(String str1){
	DAOInterface d ;
	CustomerPOJO cp = new CustomerPOJO();
	String str[] = str1.split("~",-1);
//	System.out.println(str[0]+str[1]+str[2]+str[3]+str[4]+str[5]+str[6]+str[7]+str[8]+str[9]+str[10]);
	cp.setCustomerCode(str[0]);
	cp.setCustomerName(str[1]);
	cp.setAddress1(str[2]);
	cp.setAddress2(str[3]);
	cp.setCustomerPinCode(str[4]);
	cp.setEmail(str[5]);
	cp.setContact(str[6]);
	cp.setPrimary_person(str[7]);
	cp.setRecordStatus(str[8]);
	cp.setActive_flag(str[9]);
	cp.setCreateDate(str[10]);
	cp.setCreatedBy(str[11]);
	cp.setModifiedDate(str[12]);
	cp.setModifiedBy(str[13]);
	cp.setAuthorizedDate(str[14]);
	cp.setAuthorizedBy(str[15]);
	d = new DAO();
	d.insert(cp);
}
}
