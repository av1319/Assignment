package com.fileread;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.DAO.DAO;
import com.DAO.DAOInterface;
import com.POJO.CustomerPOJO;
import com.validation.Validation;

public class FileRead {
	List<String> list = new ArrayList<String>();

	/*Methods for reading data from file and calling the DAO class 
	to insert the data into database*/
	
	public void fileRead(String fileName) throws IOException, SQLException {
		DAOInterface d;
		Validation v = new Validation();
		if(v.fileValidation(fileName)){
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		BufferedWriter fw = new BufferedWriter(new FileWriter("errorlog.txt",
				true));
		/*BufferedWriter fw1 = new BufferedWriter(new FileWriter("errorlogF.txt",
				true));*/
		String str1 = null;
		CustomerPOJO cp = new CustomerPOJO();
		boolean b1, b2, b3, b4, b5, b6, b7, b8, b9;
		int flag = 1;
		Scanner sc = new Scanner(System.in);		
		System.out.println("1.R\n2.F");
		int x = sc.nextInt();
		
		//loop for reading the file line by line using BufferedReader
		
		while ((str1 = br.readLine()) != null) {
			String str[] = str1.split("~", -1);
			cp.setCustomerCode(str[0]);
			cp.setCustomerName(str[1]);
			cp.setAddress1(str[2]);
			cp.setAddress2(str[3]);
			cp.setCustomerPinCode(str[4]);
			cp.setEmail(str[5]);
			cp.setContact(str[6]);
			cp.setPrimary_person(str[7]);
			cp.setRecordStatus(str[8]);
			cp.setActive_flag(str[9]);
			cp.setCreateDate(str[10]);
			cp.setCreatedBy(str[11]);
			cp.setModifiedDate(str[12]);
			cp.setModifiedBy(str[13]);
			cp.setAuthorizedDate(str[14]);
			cp.setAuthorizedBy(str[15]);

			b1 = v.checkCustomerName(cp.getCustomerName());
			b2 = v.checkCustomerCode(cp.getCustomerCode());
			b3 = v.checkAddress1(cp.getAddress1());
			b4 = v.checkPinCode(cp.getCustomerPinCode());
			b6 = v.domainCheck(cp.getRecordStatus());
			b5 = v.checkEmail(cp.getEmail());
			b7 = v.checkContactNumber(cp.getContact());
			b8 = v.checkCreatedBy(cp.getCreatedBy());
			b9 = v.checkCreatedDate(cp.getCreateDate());
			
			//Checking at Rejection Level
			
			if (x == 1) {
				if (b1 && b2 && b3 && b4 && b5 && b6 && b7 && b8 && b9) {
					d = new DAO();
					System.out.println(str1);
					d.insert(cp);
				} else {
					fw.write(str1);
					fw.flush();
					if (!b1) {
						fw.write(""+cp.getCustomerName());
						System.out.println(" Customer Name: "+cp.getCustomerName());
						fw.flush();
					}
					if (!b2) {
						fw.write(" Customer Code Error "+cp.getCustomerCode());
						System.out.println("Customer code: "+cp.getCustomerCode());
						fw.flush();

					}
					if (!b3) {
						
						fw.write(" Error in address "+cp.getAddress1());
						fw.flush();
					}
					if (!b4) {
						fw.write(" Pin Code Error "+(cp.getCustomerPinCode()));
						fw.flush();
					}
					if (!b5) {
						fw.write(" Email problem "+cp.getEmail());
						fw.flush();
					}
					if (!b6) {
						fw.write(" Record Status Problem "+cp.getRecordStatus());
						fw.flush();
					}
					if (!b7) {
						fw.write(" Contact problem "+cp.getContact());
						fw.flush();
					}
					if (!b8) {
						fw.write(" Problem in created by "+cp.getCreatedBy());
						fw.flush();
					}
					if (!b9) {
						fw.write(" Created date problem "+cp.getCreateDate());
						fw.flush();
					}
					fw.newLine();
					fw.flush();
				}
				

			}
			
			//Validation at file level

			else if (x == 2) {
				if (b1 && b2 && b3 && b4 && b5 && b6 && b7 && b8 && b9) {
					list.add(str1);
				} else {
					/*if (flag == 1)
						for (int k = 0; k < list.size(); k++) {
							fw1.write(list.get(k));
							fw1.flush();
							fw1.newLine();
						}
					fw1.write(str1);
					fw1.flush();
					fw1.newLine();*/
					fw.write(str1);
					fw.flush();
					if (!b1) {
						fw.write(""+cp.getCustomerName());
						System.out.println(" Customer Name: "+cp.getCustomerName());
						fw.flush();
					}
					if (!b2) {
						fw.write(" Customer Code Error "+cp.getCustomerCode());
						System.out.println("Customer code: "+cp.getCustomerCode());
						fw.flush();

					}
					if (!b3) {
						
						fw.write(" Error in address "+cp.getAddress1());
						fw.flush();
					}
					if (!b4) {
						fw.write(" Pin Code Error "+(cp.getCustomerPinCode()));
						fw.flush();
					}
					if (!b5) {
						fw.write(" Email problem "+cp.getEmail());
						fw.flush();
					}
					if (!b6) {
						fw.write(" Record Status Problem "+cp.getRecordStatus());
						fw.flush();
					}
					if (!b7) {
						fw.write(" Contact problem "+cp.getContact());
						fw.flush();
					}
					if (!b8) {
						fw.write(" Problem in created by "+cp.getCreatedBy());
						fw.flush();
					}
					if (!b9) {
						fw.write(" Created date problem "+cp.getCreateDate());
						fw.flush();
					}
					fw.newLine();
					fw.flush();
					flag = 0;
				}

			}
			

		}
		br.close();
		fw.close();
//		fw1.close();
		if(flag==1){
			Split sp = new Split();
			for(int i=0;i<list.size();i++){
				sp.split(list.get(i));
//				System.out.println(list.get(i));
			}
		}
		else if(flag==0){
			System.out.println("Error in data: check your errorlog file");
		}
		}
		else
		{
			System.out.println("Please Enter a proper extension of your file(.txt)");
		}
	}
}
