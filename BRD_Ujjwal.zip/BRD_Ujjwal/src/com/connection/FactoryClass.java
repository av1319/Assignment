package com.connection;


public class FactoryClass {
	static ConnectionInterface con;
	public static ConnectionInterface getConnectionMethod(String str){
		if(str.equalsIgnoreCase("oracle"))
		return new OracleConnection();
		else if(str.equalsIgnoreCase("mysql")){
			return new MysqlConnection();
		}
		return con;
		
	}
}
