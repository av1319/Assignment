package com.connection;

import java.sql.Connection;

public class MysqlConnection implements ConnectionInterface {

	Connection con = null;
	@Override
	public Connection myConnection() {
		// TODO Auto-generated method stub
		return con;
	}

}
