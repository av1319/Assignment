package com.connection;

import java.sql.Connection;

public interface ConnectionInterface {
	public Connection myConnection();
}
