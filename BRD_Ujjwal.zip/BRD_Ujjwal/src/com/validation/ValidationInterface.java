package com.validation;

public interface ValidationInterface {
 boolean fileValidation(String str);
}
