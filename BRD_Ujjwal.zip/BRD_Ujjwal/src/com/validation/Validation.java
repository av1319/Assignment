package com.validation;

import java.util.HashSet;

public class Validation {
	 HashSet<String> hs = new HashSet<String>();

	 //Method for file validation
	public  boolean fileValidation(String str){
		if(str.endsWith(".txt")){
			return true;
		}
		else
			return false;
	}

	//Method for domain Check
	
	public  boolean domainCheck(String str){
		if((str.equals("N")||str.equals("A")||str.equals("M")||str.equals("D")||str.equals("R"))&&(str.length()==1)&&!str.isEmpty()&&(str.length()==1)){
			return true;
		}
		return false;
		
	}
	
	//Method for validating Customer Name
	
	public  boolean checkCustomerName(String str) {
	    if(str.matches("[a-zA-Z0-9 ]+") && !str.isEmpty()&&str.length()<=30){
	    	return true;
	    }
	    else
	    return false;
	}
	
	//Method for checking Customer Code

	public  boolean checkCustomerCode(String cusCode){
		if(hs.add(cusCode)&&!hs.isEmpty()&&cusCode.length()<=10){
			return true;
		}
		else
			return false;
	}
	
	//Methods for validating address 1
	
	public boolean checkAddress1(String add1){
		if(add1.isEmpty()){
			return false;
		}
		else 
			return true;
	}
	
	//Methods for checking Pin Code
	
	public  boolean checkPinCode(String pinCode){
		if(pinCode.length()!=6&&pinCode.isEmpty()){
			return false;
			
		}
		else
			return true;
	} 
	
	//Methods for validating Contact Number
	
	public boolean checkContactNumber(String number){
		if(number.length()>0&&number.length()<20){
			return true;
		}
		else
			return false;
	}
	
	//Method for checking Email
	
	public boolean checkEmail(String email){
		if(email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")&&!email.isEmpty()){
			return true;
		}
		else
			return false;
	}
	
	//Methods for checking date is empty
	
	 public boolean checkCreatedDate(String date){
		 if(!date.isEmpty()){
			 return true;
		 }
		 else
			 return false;
	 }
	 
	 //Methods for checking created By
	 
	 public boolean checkCreatedBy(String date){
		 if(date.isEmpty())
			 return false;
		 else
			 return true;
	 }
	
}
