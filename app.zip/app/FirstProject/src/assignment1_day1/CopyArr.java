package assignment1_day1;

public class CopyArr {
	public static int[] copyOf(int[] array)//The Function take an array and returns an array
	{
		int a[]=array;
		return a;
	}
	public static void main(String[] args) {
CopyArr ca= new CopyArr();
int arr1[]={10,20,30,40,50,60,70,80} ;
int arr[]=copyOf(arr1);
System.out.println("After Copy the copied array is");
for (int i = 0; i < arr.length; i++) {
	System.out.print(arr[i]+" ");	


	}


	}
	

}
