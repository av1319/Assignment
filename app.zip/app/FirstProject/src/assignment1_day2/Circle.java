package assignment1_day2;

public class Circle {
private double radius;
private String color;

	public Circle() {
		radius = 1.0;
		color = "Red";
	}
public Circle(double radius) {
	this.radius = radius;
}

public double getRadius(){
	return radius;
}

public double getArea(){
	return (3.14*radius*radius);
}

}

class Circle1{
	
	public static void main(String[] args) {
		Circle ca= new Circle(20.9);
		double r=ca.getRadius();
		double area=ca.getArea();
		System.out.println(area);
		
		Circle ca1= new Circle();
		double r1=ca1.getRadius();
		double area1=ca1.getArea();
		System.out.println(area1);
		
		
	}
	
	
}