package pack3;

public class Accessclass1 {
	public int a;
	private int b;
	int c;
	protected int d;
	
	public void a(int a){
		System.out.println("The public value of a ="+a);
		b(20);
	}
	private void b(int b){
		System.out.println("The private value of b ="+b);
	}
	 void c (int c){
		 System.out.println("The default value of c ="+c); 
	 }
	 
	 protected void d(int d){
		 System.out.println("The protected value of d ="+d);
	 }

}

class Testclass{
	
	public static void main(String[] args) {
		Accessclass1 ac=new Accessclass1();
		ac.a(10);
		
	}
}
