package pack3;

public class VarArguments {
public static void main(String[] args) {
	Sum sm= new Sum();
	int a= sm.sum();
	int b= sm.sum(1,2,3);
	System.out.println(a);
	System.out.println(b);
}
}

class Sum{
	int sum(int...  values){
	int s=0;
	for(int i :values)
	{	
		s+=i;
	} 
	return s;
	
	}
	}