package pack2;

import pack1.Firstclass;
import pack3.Accessclass1;

public class Secondclass extends Accessclass1{

	public static void main(String[] args) {
		Secondclass f=new Secondclass();
		f.d(40);
	

	}

}
