package pack1;

public class Payroll {
	
	public void concat(String name){
		name=" vyas";
		System.out.println("The last name is "+name);
		
	}
	public static void main(String[] args) {
		Payroll  pay = new Payroll();
		String name = "Akash";
		System.out.println("The first name is : " +name);
		pay.concat(name);
		System.out.println("After the control returns" +name);
		

	}

}
