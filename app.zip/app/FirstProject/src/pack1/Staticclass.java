package pack1;

public class Staticclass {

public static void main(String[] args) {
	Logic lg1= new Logic();
	Logic lg2= new Logic();
	lg1.show();
	lg1.incA();
	lg1.incB();
	lg2.incB();
	lg2.incA();
	lg1.show();
	lg2.show();
	
	
	
}

}
 class Logic{
	 public int a=0;
	 public static int b=0;
	 public void incA(){
		 a++;
	 }
	 
	 public void incB(){
		 b++;
	 }
	 
	 public void show( ){
		 System.out.println("Value of A   is:"+a);
		 System.out.println("Value of B   is:"+b);
	 }
	 
 }