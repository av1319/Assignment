package assignment1_day4;
import java.util.Scanner;
public class Volume {

	public double volume(double s){
		
	return s*s*s;
				
	}
	
	public double volume(double r,double h){
	
		return 3.14*r*r*h;
					
		}	
	
	public double volume(double l,double b,double h){
		
		
		return l*h*b;
					
		}
	
	
	
	
public static void main(String[] args) {
	double side,radius,height,length,breadth;
    double area=0;
    int a;
    Volume v= new Volume();
	Scanner sc=new Scanner(System.in);
	
	do
	{
	

	System.out.println("Press 1 for Cube.");
	System.out.println("Press 2 for Cylinder.");
	System.out.println("Press 3 for Rectangle.");
	a=sc.nextInt();
	switch(a){
	case 1: 
        System.out.print("Enter side  ");
        side=sc.nextDouble();
        area=v.volume(side);
        System.out.print("\nThe area of the cube is: "+area);
         break;
           
case 2: System.out.print("\nEnter radius  ");
         radius=sc.nextDouble();
         System.out.print("\nEnter height  ");
         height=sc.nextDouble();
         area=v.volume(radius, height);
         System.out.print("\nThe area of cylinder is: "+area);	            
         break;
           
case 3:  System.out.print("\nEnter the length  ");
          length=sc.nextDouble();
          System.out.print("\nEnter the breadth  ");
          breadth=sc.nextDouble();
          System.out.print("\nEnter the height  ");
          height=sc.nextDouble();
          v.volume(length, breadth, height);
          System.out.print("\nThe area of the rectangle is: "+area);
          break;

default:System.out.println("enter valid inputs restart the program");
          break;       
	
	
	}
	}while(a==1||a==2||a==3);
	sc.close();
}	
	

}
