package assignment1_day4;

import java.util.*;

public abstract class Worker {
	String name;
	static final double rate = 50;
	double pay;

	abstract void computePay(int hours);

	abstract void display(String name);

}

class SalariedWorker extends Worker {
	int hoursWorked;

	void computePay(int hours) {
		this.hoursWorked = hours;

		if (hoursWorked <= 40) {
			super.pay = hoursWorked * super.rate;
		} else if (hoursWorked > 40) {
			super.pay = (40 * super.rate) + ((hoursWorked - 40) * rate);
		}

	}

	void display(String name) {
		System.out.println("Name: " + name + "Salary Rate " + rate);
		System.out.println("The total Payment that you will receive is"
				+ super.pay);
	}
}

class HourlyWorker extends Worker {
	int hoursWorked;

	void computePay(int hours) {
		this.hoursWorked = hours;

		if (hoursWorked <= 40) {
			super.pay = hoursWorked * super.rate;
		} else if (hoursWorked > 40) {
			super.pay = (40 * super.rate)
					+ ((hoursWorked - 40) * (0.5 * super.rate));
		}

	}

	void display(String name) {
		System.out.println("Name: " + name + "\nSalary Rate " + rate);
		System.out.println("The total Payment that you will receive is"
				+ super.pay);
	}

}

class TestWorker {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String name;
		double rate;
		int hours;
		int i;
		do {
			System.out
					.println("Enter \n1 for Hourly Worker\n2 for Salaried Worker");
			i = s.nextInt();
			switch (i) {
			case 1:
				System.out.println("Enter Your name");
				name = s.next();
				System.out.println("Enter Number of hours worked");
				hours = s.nextInt();
				HourlyWorker hw = new HourlyWorker();
				hw.computePay(hours);
				hw.display(name);
				break;
			case 2:
				System.out.println("Enter Your name");
				name = s.next();
				System.out.println("Enter Number of hours worked");
				hours = s.nextInt();
				SalariedWorker sw = new SalariedWorker();
				sw.computePay(hours);
				sw.display(name);
				break;

			default:
				System.out.println("Enter a Valid Choice");
				System.exit(1);
			}

		} while (i == 1 || i == 2);
		s.close();
	}
}
